const equipo = () => {
    const section = document.getElementById('equipo');
    section.innerHTML = `
        <h2>Equipo Médico</h2>
        <ul>
            <li>Dr. Juan Pérez - Veterinario General</li>
            <li>Dra. María González - Cirujana Veterinaria</li>
            <li>Dr. Pedro Rodríguez - Especialista en Exámenes de Laboratorio</li>
            <li>Dra. Ana Martínez - Esteticista Animal</li>
        </ul>
    `;
};

export default equipo;



