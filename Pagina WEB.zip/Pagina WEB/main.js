import servicios from './servicios.js';
import equipo from './equipo.js';
import contacto from './contacto.js';

servicios();
equipo();
contacto();


